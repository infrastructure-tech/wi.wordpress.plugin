<?php
/*
Plugin Name: Web Infrastructure
Description: Eons Web Infrastructure plugin for WordPress
Version: 0.0.0
Author: Eons LLC
Author URI: https://eons.llc
License: MIT License
*/

function wiwordpress_rglob($pattern, $flags = 0)
{
	$files = glob($pattern, $flags); 
	foreach (glob(dirname($pattern).'/*', GLOB_ONLYDIR|GLOB_NOSORT) as $dir)
	{
		$files = array_merge($files, wiwordpress_rglob($dir.'/'.basename($pattern), $flags));
	}
	return $files;
}
function wiwordpress_require_all()
{
	foreach (wiwordpress_rglob(dirname(__FILE__) . "/src/*.php") as $filename)
	{
		require_once($filename);
	}
	foreach (wiwordpress_rglob(dirname(__FILE__) . "/inc/*.css") as $filename)
	{
		wp_enqueue_style("wiwordpress".$filename, plugins_url($filename, __FILE__));
	}
	foreach (wiwordpress_rglob(dirname(__FILE__) . "/inc/*.js") as $filename)
	{
		wp_enqueue_script("wiwordpress".$filename, plugins_url($filename, __FILE__));
	}
}
add_action('init', 'wiwordpress_require_all');

